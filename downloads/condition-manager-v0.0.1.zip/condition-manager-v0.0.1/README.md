# condition-manager
Condition Manager for Foundry VTT.

* Requires: Foundry (0.7.9).
* Requires: dnd5e system (1.2.0).

This module adds a macro interface for management of applied conditions.

<i>Nokturnel</i>
