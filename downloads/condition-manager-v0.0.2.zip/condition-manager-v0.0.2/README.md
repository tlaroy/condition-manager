# condition-manager
Condition Manager for Foundry VTT.

* Requires: Foundry (0.7.9).
* Requires: dnd5e system (1.2.4).
* Requires: Combat Utility Belt module (1.3.8).

This module adds a macro interface for management of conditions and effects.

<i>Nokturnel</i>
