# v0.0.2 (2021-1-27)

* Added effect keys for all effects applied by conditions.

# v0.0.1 (2021-1-27)

* Initial release.