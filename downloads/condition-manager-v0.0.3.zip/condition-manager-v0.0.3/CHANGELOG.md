# v0.0.3 (2021-1-28)

* Added modifying effects in examples macro.
* Added additional comments in examples macro.
* Removed enable/disable and console macro.

# v0.0.2 (2021-1-27)

* Added effect keys for all effects applied by conditions.

# v0.0.1 (2021-1-27)

* Initial release.